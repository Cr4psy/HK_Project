Sample program that grabs a frame on the Pi and outputs it as a PGM file

Defaults to SPI channel 0 - update the "/dev/spidev0.*" value accordingly

Build with 'make'

